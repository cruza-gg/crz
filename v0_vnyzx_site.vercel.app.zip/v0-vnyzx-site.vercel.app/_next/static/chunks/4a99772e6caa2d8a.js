(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 28933, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "InvariantError", {
        enumerable: !0,
        get: function() {
            return n
        }
    });
    class n extends Error {
        constructor(e, t) {
            super(`Invariant: ${e.endsWith(".")?e:e+"."} This is a bug in Next.js.`, t), this.name = "InvariantError"
        }
    }
}, 81258, (e, t, r) => {
    "use strict";
    r._ = function(e) {
        return e && e.__esModule ? e : {
            default: e
        }
    }
}, 85635, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        BailoutToCSRError: function() {
            return u
        },
        isBailoutToCSRError: function() {
            return i
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });
    let a = "BAILOUT_TO_CLIENT_SIDE_RENDERING";
    class u extends Error {
        constructor(e) {
            super(`Bail out to client-side rendering: ${e}`), this.reason = e, this.digest = a
        }
    }

    function i(e) {
        return "object" == typeof e && null !== e && "digest" in e && e.digest === a
    }
}, 58029, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        HTTPAccessErrorStatus: function() {
            return a
        },
        HTTP_ERROR_FALLBACK_ERROR_CODE: function() {
            return i
        },
        getAccessFallbackErrorTypeByStatus: function() {
            return l
        },
        getAccessFallbackHTTPStatus: function() {
            return s
        },
        isHTTPAccessFallbackError: function() {
            return c
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });
    let a = {
            NOT_FOUND: 404,
            FORBIDDEN: 403,
            UNAUTHORIZED: 401
        },
        u = new Set(Object.values(a)),
        i = "NEXT_HTTP_ERROR_FALLBACK";

    function c(e) {
        if ("object" != typeof e || null === e || !("digest" in e) || "string" != typeof e.digest) return !1;
        let [t, r] = e.digest.split(";");
        return t === i && u.has(Number(r))
    }

    function s(e) {
        return Number(e.digest.split(";")[1])
    }

    function l(e) {
        switch (e) {
            case 401:
                return "unauthorized";
            case 403:
                return "forbidden";
            case 404:
                return "not-found";
            default:
                return
        }
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 82271, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "RedirectStatusCode", {
        enumerable: !0,
        get: function() {
            return o
        }
    });
    var n, o = ((n = {})[n.SeeOther = 303] = "SeeOther", n[n.TemporaryRedirect = 307] = "TemporaryRedirect", n[n.PermanentRedirect = 308] = "PermanentRedirect", n);
    ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 26204, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n, o = {
        REDIRECT_ERROR_CODE: function() {
            return i
        },
        RedirectType: function() {
            return c
        },
        isRedirectError: function() {
            return s
        }
    };
    for (var a in o) Object.defineProperty(r, a, {
        enumerable: !0,
        get: o[a]
    });
    let u = e.r(82271),
        i = "NEXT_REDIRECT";
    var c = ((n = {}).push = "push", n.replace = "replace", n);

    function s(e) {
        if ("object" != typeof e || null === e || !("digest" in e) || "string" != typeof e.digest) return !1;
        let t = e.digest.split(";"),
            [r, n] = t,
            o = t.slice(2, -2).join(";"),
            a = Number(t.at(-2));
        return r === i && ("replace" === n || "push" === n) && "string" == typeof o && !isNaN(a) && a in u.RedirectStatusCode
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 75682, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "isNextRouterError", {
        enumerable: !0,
        get: function() {
            return a
        }
    });
    let n = e.r(58029),
        o = e.r(26204);

    function a(e) {
        return (0, o.isRedirectError)(e) || (0, n.isHTTPAccessFallbackError)(e)
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 75159, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "ReadonlyURLSearchParams", {
        enumerable: !0,
        get: function() {
            return o
        }
    });
    class n extends Error {
        constructor() {
            super("Method unavailable on `ReadonlyURLSearchParams`. Read more: https://nextjs.org/docs/app/api-reference/functions/use-search-params#updating-searchparams")
        }
    }
    class o extends URLSearchParams {
        append() {
            throw new n
        }
        delete() {
            throw new n
        }
        set() {
            throw new n
        }
        sort() {
            throw new n
        }
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 65663, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        NavigationPromisesContext: function() {
            return l
        },
        PathParamsContext: function() {
            return s
        },
        PathnameContext: function() {
            return c
        },
        ReadonlyURLSearchParams: function() {
            return u.ReadonlyURLSearchParams
        },
        SearchParamsContext: function() {
            return i
        },
        createDevToolsInstrumentedPromise: function() {
            return d
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });
    let a = e.r(44440),
        u = e.r(75159),
        i = (0, a.createContext)(null),
        c = (0, a.createContext)(null),
        s = (0, a.createContext)(null),
        l = (0, a.createContext)(null);

    function d(e, t) {
        let r = Promise.resolve(t);
        return r.status = "fulfilled", r.value = t, r.displayName = `${e} (SSR)`, r
    }
}, 59131, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "workUnitAsyncStorageInstance", {
        enumerable: !0,
        get: function() {
            return n
        }
    });
    let n = (0, e.r(60721).createAsyncLocalStorage)()
}, 7542, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        ACTION_HEADER: function() {
            return u
        },
        FLIGHT_HEADERS: function() {
            return y
        },
        NEXT_ACTION_NOT_FOUND_HEADER: function() {
            return R
        },
        NEXT_ACTION_REVALIDATED_HEADER: function() {
            return P
        },
        NEXT_DID_POSTPONE_HEADER: function() {
            return h
        },
        NEXT_HMR_REFRESH_HASH_COOKIE: function() {
            return d
        },
        NEXT_HMR_REFRESH_HEADER: function() {
            return l
        },
        NEXT_HTML_REQUEST_ID_HEADER: function() {
            return v
        },
        NEXT_IS_PRERENDER_HEADER: function() {
            return g
        },
        NEXT_REQUEST_ID_HEADER: function() {
            return O
        },
        NEXT_REWRITTEN_PATH_HEADER: function() {
            return b
        },
        NEXT_REWRITTEN_QUERY_HEADER: function() {
            return E
        },
        NEXT_ROUTER_PREFETCH_HEADER: function() {
            return c
        },
        NEXT_ROUTER_SEGMENT_PREFETCH_HEADER: function() {
            return s
        },
        NEXT_ROUTER_STALE_TIME_HEADER: function() {
            return m
        },
        NEXT_ROUTER_STATE_TREE_HEADER: function() {
            return i
        },
        NEXT_RSC_UNION_QUERY: function() {
            return _
        },
        NEXT_URL: function() {
            return f
        },
        RSC_CONTENT_TYPE_HEADER: function() {
            return p
        },
        RSC_HEADER: function() {
            return a
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });
    let a = "rsc",
        u = "next-action",
        i = "next-router-state-tree",
        c = "next-router-prefetch",
        s = "next-router-segment-prefetch",
        l = "next-hmr-refresh",
        d = "__next_hmr_refresh_hash__",
        f = "next-url",
        p = "text/x-component",
        y = [a, i, c, l, s],
        _ = "_rsc",
        m = "x-nextjs-stale-time",
        h = "x-nextjs-postponed",
        b = "x-nextjs-rewritten-path",
        E = "x-nextjs-rewritten-query",
        g = "x-nextjs-prerender",
        R = "x-nextjs-action-not-found",
        O = "x-nextjs-request-id",
        v = "x-nextjs-html-request-id",
        P = "x-action-revalidated";
    ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 72786, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        getCacheSignal: function() {
            return m
        },
        getDraftModeProviderForCacheScope: function() {
            return _
        },
        getHmrRefreshHash: function() {
            return f
        },
        getPrerenderResumeDataCache: function() {
            return l
        },
        getRenderResumeDataCache: function() {
            return d
        },
        getRuntimeStagePromise: function() {
            return h
        },
        getServerComponentsHmrCache: function() {
            return y
        },
        isHmrRefresh: function() {
            return p
        },
        throwForMissingRequestStore: function() {
            return c
        },
        throwInvariantForMissingStore: function() {
            return s
        },
        workUnitAsyncStorage: function() {
            return a.workUnitAsyncStorageInstance
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });
    let a = e.r(59131),
        u = e.r(7542),
        i = e.r(28933);

    function c(e) {
        throw Object.defineProperty(Error(`\`${e}\` was called outside a request scope. Read more: https://nextjs.org/docs/messages/next-dynamic-api-wrong-context`), "__NEXT_ERROR_CODE", {
            value: "E251",
            enumerable: !1,
            configurable: !0
        })
    }

    function s() {
        throw Object.defineProperty(new i.InvariantError("Expected workUnitAsyncStorage to have a store."), "__NEXT_ERROR_CODE", {
            value: "E696",
            enumerable: !1,
            configurable: !0
        })
    }

    function l(e) {
        switch (e.type) {
            case "prerender":
            case "prerender-runtime":
            case "prerender-ppr":
            case "prerender-client":
                return e.prerenderResumeDataCache;
            case "request":
                if (e.prerenderResumeDataCache) return e.prerenderResumeDataCache;
            case "prerender-legacy":
            case "cache":
            case "private-cache":
            case "unstable-cache":
                return null;
            default:
                return e
        }
    }

    function d(e) {
        switch (e.type) {
            case "request":
            case "prerender":
            case "prerender-runtime":
            case "prerender-client":
                if (e.renderResumeDataCache) return e.renderResumeDataCache;
            case "prerender-ppr":
                return e.prerenderResumeDataCache ? ? null;
            case "cache":
            case "private-cache":
            case "unstable-cache":
            case "prerender-legacy":
                return null;
            default:
                return e
        }
    }

    function f(e, t) {
        if (e.dev) switch (t.type) {
            case "cache":
            case "private-cache":
            case "prerender":
            case "prerender-runtime":
                return t.hmrRefreshHash;
            case "request":
                var r;
                return null == (r = t.cookies.get(u.NEXT_HMR_REFRESH_HASH_COOKIE)) ? void 0 : r.value
        }
    }

    function p(e, t) {
        if (e.dev) switch (t.type) {
            case "cache":
            case "private-cache":
            case "request":
                return t.isHmrRefresh ? ? !1
        }
        return !1
    }

    function y(e, t) {
        if (e.dev) switch (t.type) {
            case "cache":
            case "private-cache":
            case "request":
                return t.serverComponentsHmrCache
        }
    }

    function _(e, t) {
        if (e.isDraftMode) switch (t.type) {
            case "cache":
            case "private-cache":
            case "unstable-cache":
            case "prerender-runtime":
            case "request":
                return t.draftMode
        }
    }

    function m(e) {
        switch (e.type) {
            case "prerender":
            case "prerender-client":
            case "prerender-runtime":
                return e.cacheSignal;
            case "request":
                if (e.cacheSignal) return e.cacheSignal;
            case "prerender-ppr":
            case "prerender-legacy":
            case "cache":
            case "private-cache":
            case "unstable-cache":
                return null;
            default:
                return e
        }
    }

    function h(e) {
        switch (e.type) {
            case "prerender-runtime":
            case "private-cache":
                return e.runtimeStagePromise;
            case "prerender":
            case "prerender-client":
            case "prerender-ppr":
            case "prerender-legacy":
            case "request":
            case "cache":
            case "unstable-cache":
                return null;
            default:
                return e
        }
    }
}, 44066, (e, t, r) => {
    "use strict";

    function n(e) {
        if ("function" != typeof WeakMap) return null;
        var t = new WeakMap,
            r = new WeakMap;
        return (n = function(e) {
            return e ? r : t
        })(e)
    }
    r._ = function(e, t) {
        if (!t && e && e.__esModule) return e;
        if (null === e || "object" != typeof e && "function" != typeof e) return {
            default: e
        };
        var r = n(t);
        if (r && r.has(e)) return r.get(e);
        var o = {
                __proto__: null
            },
            a = Object.defineProperty && Object.getOwnPropertyDescriptor;
        for (var u in e)
            if ("default" !== u && Object.prototype.hasOwnProperty.call(e, u)) {
                var i = a ? Object.getOwnPropertyDescriptor(e, u) : null;
                i && (i.get || i.set) ? Object.defineProperty(o, u, i) : o[u] = e[u]
            }
        return o.default = e, r && r.set(e, o), o
    }
}, 2019, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        DEFAULT_SEGMENT_KEY: function() {
            return d
        },
        NOT_FOUND_SEGMENT_KEY: function() {
            return f
        },
        PAGE_SEGMENT_KEY: function() {
            return l
        },
        addSearchParamsIfPageSegment: function() {
            return c
        },
        computeSelectedLayoutSegment: function() {
            return s
        },
        getSegmentValue: function() {
            return a
        },
        getSelectedLayoutSegmentPath: function() {
            return function e(t, r, n = !0, o = []) {
                let u;
                if (n) u = t[1][r];
                else {
                    let e = t[1];
                    u = e.children ? ? Object.values(e)[0]
                }
                if (!u) return o;
                let i = a(u[0]);
                return !i || i.startsWith(l) ? o : (o.push(i), e(u, r, !1, o))
            }
        },
        isGroupSegment: function() {
            return u
        },
        isParallelRouteSegment: function() {
            return i
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });

    function a(e) {
        return Array.isArray(e) ? e[1] : e
    }

    function u(e) {
        return "(" === e[0] && e.endsWith(")")
    }

    function i(e) {
        return e.startsWith("@") && "@children" !== e
    }

    function c(e, t) {
        if (e.includes(l)) {
            let e = JSON.stringify(t);
            return "{}" !== e ? l + "?" + e : l
        }
        return e
    }

    function s(e, t) {
        if (!e || 0 === e.length) return null;
        let r = "children" === t ? e[0] : e[e.length - 1];
        return r === d ? null : r
    }
    let l = "__PAGE__",
        d = "__DEFAULT__",
        f = "/_not-found"
}, 51878, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        UnrecognizedActionError: function() {
            return a
        },
        unstable_isUnrecognizedActionError: function() {
            return u
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });
    class a extends Error {
        constructor(...e) {
            super(...e), this.name = "UnrecognizedActionError"
        }
    }

    function u(e) {
        return !!(e && "object" == typeof e && e instanceof a)
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 62751, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "actionAsyncStorageInstance", {
        enumerable: !0,
        get: function() {
            return n
        }
    });
    let n = (0, e.r(60721).createAsyncLocalStorage)()
}, 66629, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "actionAsyncStorage", {
        enumerable: !0,
        get: function() {
            return n.actionAsyncStorageInstance
        }
    });
    let n = e.r(62751)
}, 15539, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        getRedirectError: function() {
            return c
        },
        getRedirectStatusCodeFromError: function() {
            return p
        },
        getRedirectTypeFromError: function() {
            return f
        },
        getURLFromRedirectError: function() {
            return d
        },
        permanentRedirect: function() {
            return l
        },
        redirect: function() {
            return s
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });
    let a = e.r(82271),
        u = e.r(26204),
        i = "u" < typeof window ? e.r(66629).actionAsyncStorage : void 0;

    function c(e, t, r = a.RedirectStatusCode.TemporaryRedirect) {
        let n = Object.defineProperty(Error(u.REDIRECT_ERROR_CODE), "__NEXT_ERROR_CODE", {
            value: "E394",
            enumerable: !1,
            configurable: !0
        });
        return n.digest = `${u.REDIRECT_ERROR_CODE};${t};${e};${r};`, n
    }

    function s(e, t) {
        throw c(e, t ? ? = i ? .getStore() ? .isAction ? u.RedirectType.push : u.RedirectType.replace, a.RedirectStatusCode.TemporaryRedirect)
    }

    function l(e, t = u.RedirectType.replace) {
        throw c(e, t, a.RedirectStatusCode.PermanentRedirect)
    }

    function d(e) {
        return (0, u.isRedirectError)(e) ? e.digest.split(";").slice(2, -2).join(";") : null
    }

    function f(e) {
        if (!(0, u.isRedirectError)(e)) throw Object.defineProperty(Error("Not a redirect error"), "__NEXT_ERROR_CODE", {
            value: "E260",
            enumerable: !1,
            configurable: !0
        });
        return e.digest.split(";", 2)[1]
    }

    function p(e) {
        if (!(0, u.isRedirectError)(e)) throw Object.defineProperty(Error("Not a redirect error"), "__NEXT_ERROR_CODE", {
            value: "E260",
            enumerable: !1,
            configurable: !0
        });
        return Number(e.digest.split(";").at(-2))
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 31270, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        AppRouterContext: function() {
            return u
        },
        GlobalLayoutRouterContext: function() {
            return c
        },
        LayoutRouterContext: function() {
            return i
        },
        MissingSlotContext: function() {
            return l
        },
        TemplateContext: function() {
            return s
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });
    let a = e.r(81258)._(e.r(44440)),
        u = a.default.createContext(null),
        i = a.default.createContext(null),
        c = a.default.createContext(null),
        s = a.default.createContext(null),
        l = a.default.createContext(new Set)
}, 24857, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        ServerInsertedHTMLContext: function() {
            return u
        },
        useServerInsertedHTML: function() {
            return i
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });
    let a = e.r(44066)._(e.r(44440)),
        u = a.default.createContext(null);

    function i(e) {
        let t = (0, a.useContext)(u);
        t && t(e)
    }
}, 93703, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "notFound", {
        enumerable: !0,
        get: function() {
            return a
        }
    });
    let n = e.r(58029),
        o = `${n.HTTP_ERROR_FALLBACK_ERROR_CODE};404`;

    function a() {
        let e = Object.defineProperty(Error(o), "__NEXT_ERROR_CODE", {
            value: "E394",
            enumerable: !1,
            configurable: !0
        });
        throw e.digest = o, e
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 82526, (e, t, r) => {
    "use strict";

    function n() {
        throw Object.defineProperty(Error("`forbidden()` is experimental and only allowed to be enabled when `experimental.authInterrupts` is enabled."), "__NEXT_ERROR_CODE", {
            value: "E488",
            enumerable: !1,
            configurable: !0
        })
    }
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "forbidden", {
        enumerable: !0,
        get: function() {
            return n
        }
    }), e.r(58029).HTTP_ERROR_FALLBACK_ERROR_CODE, ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 87206, (e, t, r) => {
    "use strict";

    function n() {
        throw Object.defineProperty(Error("`unauthorized()` is experimental and only allowed to be used when `experimental.authInterrupts` is enabled."), "__NEXT_ERROR_CODE", {
            value: "E411",
            enumerable: !1,
            configurable: !0
        })
    }
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "unauthorized", {
        enumerable: !0,
        get: function() {
            return n
        }
    }), e.r(58029).HTTP_ERROR_FALLBACK_ERROR_CODE, ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 40211, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "unstable_rethrow", {
        enumerable: !0,
        get: function() {
            return function e(t) {
                if ((0, o.isNextRouterError)(t) || (0, n.isBailoutToCSRError)(t)) throw t;
                t instanceof Error && "cause" in t && e(t.cause)
            }
        }
    });
    let n = e.r(85635),
        o = e.r(75682);
    ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 38747, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        isHangingPromiseRejectionError: function() {
            return a
        },
        makeDevtoolsIOAwarePromise: function() {
            return d
        },
        makeHangingPromise: function() {
            return s
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });

    function a(e) {
        return "object" == typeof e && null !== e && "digest" in e && e.digest === u
    }
    let u = "HANGING_PROMISE_REJECTION";
    class i extends Error {
        constructor(e, t) {
            super(`During prerendering, ${t} rejects when the prerender is complete. Typically these errors are handled by React but if you move ${t} to a different context by using \`setTimeout\`, \`after\`, or similar functions you may observe this error and you should handle it in that context. This occurred at route "${e}".`), this.route = e, this.expression = t, this.digest = u
        }
    }
    let c = new WeakMap;

    function s(e, t, r) {
        if (e.aborted) return Promise.reject(new i(t, r)); {
            let n = new Promise((n, o) => {
                let a = o.bind(null, new i(t, r)),
                    u = c.get(e);
                if (u) u.push(a);
                else {
                    let t = [a];
                    c.set(e, t), e.addEventListener("abort", () => {
                        for (let e = 0; e < t.length; e++) t[e]()
                    }, {
                        once: !0
                    })
                }
            });
            return n.catch(l), n
        }
    }

    function l() {}

    function d(e, t, r) {
        return t.stagedRendering ? t.stagedRendering.delayUntilStage(r, void 0, e) : new Promise(t => {
            setTimeout(() => {
                t(e)
            }, 0)
        })
    }
}, 56465, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "isPostpone", {
        enumerable: !0,
        get: function() {
            return o
        }
    });
    let n = Symbol.for("react.postpone");

    function o(e) {
        return "object" == typeof e && null !== e && e.$$typeof === n
    }
}, 29123, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        DynamicServerError: function() {
            return u
        },
        isDynamicServerError: function() {
            return i
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });
    let a = "DYNAMIC_SERVER_USAGE";
    class u extends Error {
        constructor(e) {
            super(`Dynamic server usage: ${e}`), this.description = e, this.digest = a
        }
    }

    function i(e) {
        return "object" == typeof e && null !== e && "digest" in e && "string" == typeof e.digest && e.digest === a
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 95238, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        StaticGenBailoutError: function() {
            return u
        },
        isStaticGenBailoutError: function() {
            return i
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });
    let a = "NEXT_STATIC_GEN_BAILOUT";
    class u extends Error {
        constructor(...e) {
            super(...e), this.code = a
        }
    }

    function i(e) {
        return "object" == typeof e && null !== e && "code" in e && e.code === a
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 61139, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        METADATA_BOUNDARY_NAME: function() {
            return a
        },
        OUTLET_BOUNDARY_NAME: function() {
            return i
        },
        ROOT_LAYOUT_BOUNDARY_NAME: function() {
            return c
        },
        VIEWPORT_BOUNDARY_NAME: function() {
            return u
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });
    let a = "__next_metadata_boundary__",
        u = "__next_viewport_boundary__",
        i = "__next_outlet_boundary__",
        c = "__next_root_layout_boundary__"
}, 7280, (e, t, r) => {
    "use strict";
    var n = e.i(17141);
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var o = {
        atLeastOneTask: function() {
            return c
        },
        scheduleImmediate: function() {
            return i
        },
        scheduleOnNextTick: function() {
            return u
        },
        waitAtLeastOneReactRenderTask: function() {
            return s
        }
    };
    for (var a in o) Object.defineProperty(r, a, {
        enumerable: !0,
        get: o[a]
    });
    let u = e => {
            Promise.resolve().then(() => {
                n.default.nextTick(e)
            })
        },
        i = e => {
            setImmediate(e)
        };

    function c() {
        return new Promise(e => i(e))
    }

    function s() {
        return new Promise(e => setImmediate(e))
    }
}, 34070, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n, o, a = {
        Postpone: function() {
            return T
        },
        PreludeState: function() {
            return J
        },
        abortAndThrowOnSynchronousRequestDataAccess: function() {
            return S
        },
        abortOnSynchronousPlatformIOAccess: function() {
            return j
        },
        accessedDynamicData: function() {
            return k
        },
        annotateDynamicAccess: function() {
            return $
        },
        consumeDynamicAccess: function() {
            return I
        },
        createDynamicTrackingState: function() {
            return b
        },
        createDynamicValidationState: function() {
            return E
        },
        createHangingInputAbortSignal: function() {
            return L
        },
        createRenderInBrowserAbortSignal: function() {
            return H
        },
        delayUntilRuntimeStage: function() {
            return er
        },
        formatDynamicAPIAccesses: function() {
            return U
        },
        getFirstDynamicReason: function() {
            return g
        },
        getStaticShellDisallowedDynamicReasons: function() {
            return et
        },
        isDynamicPostpone: function() {
            return x
        },
        isPrerenderInterruptedError: function() {
            return N
        },
        logDisallowedDynamicError: function() {
            return Z
        },
        markCurrentScopeAsDynamic: function() {
            return R
        },
        postponeWithTracking: function() {
            return w
        },
        throwIfDisallowedDynamic: function() {
            return ee
        },
        throwToInterruptStaticGeneration: function() {
            return O
        },
        trackAllowedDynamicAccess: function() {
            return z
        },
        trackDynamicDataInDynamicRender: function() {
            return v
        },
        trackDynamicHoleInRuntimeShell: function() {
            return K
        },
        trackDynamicHoleInStaticShell: function() {
            return V
        },
        useDynamicRouteParams: function() {
            return X
        },
        useDynamicSearchParams: function() {
            return B
        }
    };
    for (var u in a) Object.defineProperty(r, u, {
        enumerable: !0,
        get: a[u]
    });
    let i = (n = e.r(44440)) && n.__esModule ? n : {
            default: n
        },
        c = e.r(29123),
        s = e.r(95238),
        l = e.r(72786),
        d = e.r(42907),
        f = e.r(38747),
        p = e.r(61139),
        y = e.r(7280),
        _ = e.r(85635),
        m = e.r(28933),
        h = "function" == typeof i.default.unstable_postpone;

    function b(e) {
        return {
            isDebugDynamicAccesses: e,
            dynamicAccesses: [],
            syncDynamicErrorWithStack: null
        }
    }

    function E() {
        return {
            hasSuspenseAboveBody: !1,
            hasDynamicMetadata: !1,
            dynamicMetadata: null,
            hasDynamicViewport: !1,
            hasAllowedDynamic: !1,
            dynamicErrors: []
        }
    }

    function g(e) {
        var t;
        return null == (t = e.dynamicAccesses[0]) ? void 0 : t.expression
    }

    function R(e, t, r) {
        if (t) switch (t.type) {
            case "cache":
            case "unstable-cache":
            case "private-cache":
                return
        }
        if (!e.forceDynamic && !e.forceStatic) {
            if (e.dynamicShouldError) throw Object.defineProperty(new s.StaticGenBailoutError(`Route ${e.route} with \`dynamic = "error"\` couldn't be rendered statically because it used \`${r}\`. See more info here: https://nextjs.org/docs/app/building-your-application/rendering/static-and-dynamic#dynamic-rendering`), "__NEXT_ERROR_CODE", {
                value: "E553",
                enumerable: !1,
                configurable: !0
            });
            if (t) switch (t.type) {
                case "prerender-ppr":
                    return w(e.route, r, t.dynamicTracking);
                case "prerender-legacy":
                    t.revalidate = 0;
                    let n = Object.defineProperty(new c.DynamicServerError(`Route ${e.route} couldn't be rendered statically because it used ${r}. See more info here: https://nextjs.org/docs/messages/dynamic-server-error`), "__NEXT_ERROR_CODE", {
                        value: "E550",
                        enumerable: !1,
                        configurable: !0
                    });
                    throw e.dynamicUsageDescription = r, e.dynamicUsageStack = n.stack, n
            }
        }
    }

    function O(e, t, r) {
        let n = Object.defineProperty(new c.DynamicServerError(`Route ${t.route} couldn't be rendered statically because it used \`${e}\`. See more info here: https://nextjs.org/docs/messages/dynamic-server-error`), "__NEXT_ERROR_CODE", {
            value: "E558",
            enumerable: !1,
            configurable: !0
        });
        throw r.revalidate = 0, t.dynamicUsageDescription = e, t.dynamicUsageStack = n.stack, n
    }

    function v(e) {
        switch (e.type) {
            case "cache":
            case "unstable-cache":
            case "private-cache":
                return
        }
    }

    function P(e, t, r) {
        let n = C(`Route ${e} needs to bail out of prerendering at this point because it used ${t}.`);
        r.controller.abort(n);
        let o = r.dynamicTracking;
        o && o.dynamicAccesses.push({
            stack: o.isDebugDynamicAccesses ? Error().stack : void 0,
            expression: t
        })
    }

    function j(e, t, r, n) {
        let o = n.dynamicTracking;
        P(e, t, n), o && null === o.syncDynamicErrorWithStack && (o.syncDynamicErrorWithStack = r)
    }

    function S(e, t, r, n) {
        if (!1 === n.controller.signal.aborted) {
            P(e, t, n);
            let o = n.dynamicTracking;
            o && null === o.syncDynamicErrorWithStack && (o.syncDynamicErrorWithStack = r)
        }
        throw C(`Route ${e} needs to bail out of prerendering at this point because it used ${t}.`)
    }

    function T({
        reason: e,
        route: t
    }) {
        let r = l.workUnitAsyncStorage.getStore();
        w(t, e, r && "prerender-ppr" === r.type ? r.dynamicTracking : null)
    }

    function w(e, t, r) {
        (function() {
            if (!h) throw Object.defineProperty(Error("Invariant: React.unstable_postpone is not defined. This suggests the wrong version of React was loaded. This is a bug in Next.js"), "__NEXT_ERROR_CODE", {
                value: "E224",
                enumerable: !1,
                configurable: !0
            })
        })(), r && r.dynamicAccesses.push({
            stack: r.isDebugDynamicAccesses ? Error().stack : void 0,
            expression: t
        }), i.default.unstable_postpone(D(e, t))
    }

    function D(e, t) {
        return `Route ${e} needs to bail out of prerendering at this point because it used ${t}. React throws this special object to indicate where. It should not be caught by your own try/catch. Learn more: https://nextjs.org/docs/messages/ppr-caught-error`
    }

    function x(e) {
        return "object" == typeof e && null !== e && "string" == typeof e.message && A(e.message)
    }

    function A(e) {
        return e.includes("needs to bail out of prerendering at this point because it used") && e.includes("Learn more: https://nextjs.org/docs/messages/ppr-caught-error")
    }
    if (!1 === A(D("%%%", "^^^"))) throw Object.defineProperty(Error("Invariant: isDynamicPostpone misidentified a postpone reason. This is a bug in Next.js"), "__NEXT_ERROR_CODE", {
        value: "E296",
        enumerable: !1,
        configurable: !0
    });
    let M = "NEXT_PRERENDER_INTERRUPTED";

    function C(e) {
        let t = Object.defineProperty(Error(e), "__NEXT_ERROR_CODE", {
            value: "E394",
            enumerable: !1,
            configurable: !0
        });
        return t.digest = M, t
    }

    function N(e) {
        return "object" == typeof e && null !== e && e.digest === M && "name" in e && "message" in e && e instanceof Error
    }

    function k(e) {
        return e.length > 0
    }

    function I(e, t) {
        return e.dynamicAccesses.push(...t.dynamicAccesses), e.dynamicAccesses
    }

    function U(e) {
        return e.filter(e => "string" == typeof e.stack && e.stack.length > 0).map(({
            expression: e,
            stack: t
        }) => (t = t.split("\n").slice(4).filter(e => !(e.includes("node_modules/next/") || e.includes(" (<anonymous>)") || e.includes(" (node:"))).join("\n"), `Dynamic API Usage Debug - ${e}:
${t}`))
    }

    function H() {
        let e = new AbortController;
        return e.abort(Object.defineProperty(new _.BailoutToCSRError("Render in Browser"), "__NEXT_ERROR_CODE", {
            value: "E721",
            enumerable: !1,
            configurable: !0
        })), e.signal
    }

    function L(e) {
        switch (e.type) {
            case "prerender":
            case "prerender-runtime":
                let t = new AbortController;
                if (e.cacheSignal) e.cacheSignal.inputReady().then(() => {
                    t.abort()
                });
                else {
                    let r = (0, l.getRuntimeStagePromise)(e);
                    r ? r.then(() => (0, y.scheduleOnNextTick)(() => t.abort())) : (0, y.scheduleOnNextTick)(() => t.abort())
                }
                return t.signal;
            case "prerender-client":
            case "prerender-ppr":
            case "prerender-legacy":
            case "request":
            case "cache":
            case "private-cache":
            case "unstable-cache":
                return
        }
    }

    function $(e, t) {
        let r = t.dynamicTracking;
        r && r.dynamicAccesses.push({
            stack: r.isDebugDynamicAccesses ? Error().stack : void 0,
            expression: e
        })
    }

    function X(e) {
        let t = d.workAsyncStorage.getStore(),
            r = l.workUnitAsyncStorage.getStore();
        if (t && r) switch (r.type) {
            case "prerender-client":
            case "prerender":
                {
                    let n = r.fallbackRouteParams;n && n.size > 0 && i.default.use((0, f.makeHangingPromise)(r.renderSignal, t.route, e));
                    break
                }
            case "prerender-ppr":
                {
                    let n = r.fallbackRouteParams;
                    if (n && n.size > 0) return w(t.route, e, r.dynamicTracking);
                    break
                }
            case "prerender-runtime":
                throw Object.defineProperty(new m.InvariantError(`\`${e}\` was called during a runtime prerender. Next.js should be preventing ${e} from being included in server components statically, but did not in this case.`), "__NEXT_ERROR_CODE", {
                    value: "E771",
                    enumerable: !1,
                    configurable: !0
                });
            case "cache":
            case "private-cache":
                throw Object.defineProperty(new m.InvariantError(`\`${e}\` was called inside a cache scope. Next.js should be preventing ${e} from being included in server components statically, but did not in this case.`), "__NEXT_ERROR_CODE", {
                    value: "E745",
                    enumerable: !1,
                    configurable: !0
                })
        }
    }

    function B(e) {
        let t = d.workAsyncStorage.getStore(),
            r = l.workUnitAsyncStorage.getStore();
        if (t) switch (!r && (0, l.throwForMissingRequestStore)(e), r.type) {
            case "prerender-client":
                i.default.use((0, f.makeHangingPromise)(r.renderSignal, t.route, e));
                break;
            case "prerender-legacy":
            case "prerender-ppr":
                if (t.forceStatic) return;
                throw Object.defineProperty(new _.BailoutToCSRError(e), "__NEXT_ERROR_CODE", {
                    value: "E394",
                    enumerable: !1,
                    configurable: !0
                });
            case "prerender":
            case "prerender-runtime":
                throw Object.defineProperty(new m.InvariantError(`\`${e}\` was called from a Server Component. Next.js should be preventing ${e} from being included in server components statically, but did not in this case.`), "__NEXT_ERROR_CODE", {
                    value: "E795",
                    enumerable: !1,
                    configurable: !0
                });
            case "cache":
            case "unstable-cache":
            case "private-cache":
                throw Object.defineProperty(new m.InvariantError(`\`${e}\` was called inside a cache scope. Next.js should be preventing ${e} from being included in server components statically, but did not in this case.`), "__NEXT_ERROR_CODE", {
                    value: "E745",
                    enumerable: !1,
                    configurable: !0
                });
            case "request":
                return
        }
    }
    let F = /\n\s+at Suspense \(<anonymous>\)/,
        W = RegExp(`\\n\\s+at Suspense \\(<anonymous>\\)(?:(?!\\n\\s+at (?:body|div|main|section|article|aside|header|footer|nav|form|p|span|h1|h2|h3|h4|h5|h6) \\(<anonymous>\\))[\\s\\S])*?\\n\\s+at ${p.ROOT_LAYOUT_BOUNDARY_NAME} \\([^\\n]*\\)`),
        G = RegExp(`\\n\\s+at ${p.METADATA_BOUNDARY_NAME}[\\n\\s]`),
        q = RegExp(`\\n\\s+at ${p.VIEWPORT_BOUNDARY_NAME}[\\n\\s]`),
        Y = RegExp(`\\n\\s+at ${p.OUTLET_BOUNDARY_NAME}[\\n\\s]`);

    function z(e, t, r, n) {
        if (!Y.test(t)) {
            if (G.test(t)) {
                r.hasDynamicMetadata = !0;
                return
            }
            if (q.test(t)) {
                r.hasDynamicViewport = !0;
                return
            }
            if (W.test(t)) {
                r.hasAllowedDynamic = !0, r.hasSuspenseAboveBody = !0;
                return
            } else if (F.test(t)) {
                r.hasAllowedDynamic = !0;
                return
            } else {
                if (n.syncDynamicErrorWithStack) return void r.dynamicErrors.push(n.syncDynamicErrorWithStack);
                let o = Q(`Route "${e.route}": Uncached data was accessed outside of <Suspense>. This delays the entire page from rendering, resulting in a slow user experience. Learn more: https://nextjs.org/docs/messages/blocking-route`, t);
                return void r.dynamicErrors.push(o)
            }
        }
    }

    function K(e, t, r, n) {
        if (!Y.test(t)) {
            if (G.test(t)) {
                r.dynamicMetadata = Q(`Route "${e.route}": Uncached data or \`connection()\` was accessed inside \`generateMetadata\`. Except for this instance, the page would have been entirely prerenderable which may have been the intended behavior. See more info here: https://nextjs.org/docs/messages/next-prerender-dynamic-metadata`, t);
                return
            }
            if (q.test(t)) {
                let n = Q(`Route "${e.route}": Uncached data or \`connection()\` was accessed inside \`generateViewport\`. This delays the entire page from rendering, resulting in a slow user experience. Learn more: https://nextjs.org/docs/messages/next-prerender-dynamic-viewport`, t);
                r.dynamicErrors.push(n);
                return
            }
            if (W.test(t)) {
                r.hasAllowedDynamic = !0, r.hasSuspenseAboveBody = !0;
                return
            } else if (F.test(t)) {
                r.hasAllowedDynamic = !0;
                return
            } else {
                if (n.syncDynamicErrorWithStack) return void r.dynamicErrors.push(n.syncDynamicErrorWithStack);
                let o = Q(`Route "${e.route}": Uncached data or \`connection()\` was accessed outside of \`<Suspense>\`. This delays the entire page from rendering, resulting in a slow user experience. Learn more: https://nextjs.org/docs/messages/blocking-route`, t);
                return void r.dynamicErrors.push(o)
            }
        }
    }

    function V(e, t, r, n) {
        if (!Y.test(t)) {
            if (G.test(t)) {
                r.dynamicMetadata = Q(`Route "${e.route}": Runtime data such as \`cookies()\`, \`headers()\`, \`params\`, or \`searchParams\` was accessed inside \`generateMetadata\` or you have file-based metadata such as icons that depend on dynamic params segments. Except for this instance, the page would have been entirely prerenderable which may have been the intended behavior. See more info here: https://nextjs.org/docs/messages/next-prerender-dynamic-metadata`, t);
                return
            }
            if (q.test(t)) {
                let n = Q(`Route "${e.route}": Runtime data such as \`cookies()\`, \`headers()\`, \`params\`, or \`searchParams\` was accessed inside \`generateViewport\`. This delays the entire page from rendering, resulting in a slow user experience. Learn more: https://nextjs.org/docs/messages/next-prerender-dynamic-viewport`, t);
                r.dynamicErrors.push(n);
                return
            }
            if (W.test(t)) {
                r.hasAllowedDynamic = !0, r.hasSuspenseAboveBody = !0;
                return
            } else if (F.test(t)) {
                r.hasAllowedDynamic = !0;
                return
            } else {
                if (n.syncDynamicErrorWithStack) return void r.dynamicErrors.push(n.syncDynamicErrorWithStack);
                let o = Q(`Route "${e.route}": Runtime data such as \`cookies()\`, \`headers()\`, \`params\`, or \`searchParams\` was accessed outside of \`<Suspense>\`. This delays the entire page from rendering, resulting in a slow user experience. Learn more: https://nextjs.org/docs/messages/blocking-route`, t);
                return void r.dynamicErrors.push(o)
            }
        }
    }

    function Q(e, t) {
        let r = Object.defineProperty(Error(e), "__NEXT_ERROR_CODE", {
            value: "E394",
            enumerable: !1,
            configurable: !0
        });
        return r.stack = r.name + ": " + e + t, r
    }
    var J = ((o = {})[o.Full = 0] = "Full", o[o.Empty = 1] = "Empty", o[o.Errored = 2] = "Errored", o);

    function Z(e, t) {
        console.error(t), e.dev || (e.hasReadableErrorStacks ? console.error(`To get a more detailed stack trace and pinpoint the issue, start the app in development mode by running \`next dev\`, then open "${e.route}" in your browser to investigate the error.`) : console.error(`To get a more detailed stack trace and pinpoint the issue, try one of the following:
  - Start the app in development mode by running \`next dev\`, then open "${e.route}" in your browser to investigate the error.
  - Rerun the production build with \`next build --debug-prerender\` to generate better stack traces.`))
    }

    function ee(e, t, r, n) {
        if (n.syncDynamicErrorWithStack) throw Z(e, n.syncDynamicErrorWithStack), new s.StaticGenBailoutError;
        if (0 !== t) {
            if (r.hasSuspenseAboveBody) return;
            let n = r.dynamicErrors;
            if (n.length > 0) {
                for (let t = 0; t < n.length; t++) Z(e, n[t]);
                throw new s.StaticGenBailoutError
            }
            if (r.hasDynamicViewport) throw console.error(`Route "${e.route}" has a \`generateViewport\` that depends on Request data (\`cookies()\`, etc...) or uncached external data (\`fetch(...)\`, etc...) without explicitly allowing fully dynamic rendering. See more info here: https://nextjs.org/docs/messages/next-prerender-dynamic-viewport`), new s.StaticGenBailoutError;
            if (1 === t) throw console.error(`Route "${e.route}" did not produce a static shell and Next.js was unable to determine a reason. This is a bug in Next.js.`), new s.StaticGenBailoutError
        } else if (!1 === r.hasAllowedDynamic && r.hasDynamicMetadata) throw console.error(`Route "${e.route}" has a \`generateMetadata\` that depends on Request data (\`cookies()\`, etc...) or uncached external data (\`fetch(...)\`, etc...) when the rest of the route does not. See more info here: https://nextjs.org/docs/messages/next-prerender-dynamic-metadata`), new s.StaticGenBailoutError
    }

    function et(e, t, r) {
        if (r.hasSuspenseAboveBody) return [];
        if (0 !== t) {
            let n = r.dynamicErrors;
            if (n.length > 0) return n;
            if (1 === t) return [Object.defineProperty(new m.InvariantError(`Route "${e.route}" did not produce a static shell and Next.js was unable to determine a reason.`), "__NEXT_ERROR_CODE", {
                value: "E936",
                enumerable: !1,
                configurable: !0
            })]
        } else if (!1 === r.hasAllowedDynamic && 0 === r.dynamicErrors.length && r.dynamicMetadata) return [r.dynamicMetadata];
        return []
    }

    function er(e, t) {
        return e.runtimeStagePromise ? e.runtimeStagePromise.then(() => t) : t
    }
}, 61298, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "unstable_rethrow", {
        enumerable: !0,
        get: function() {
            return function e(t) {
                if ((0, u.isNextRouterError)(t) || (0, a.isBailoutToCSRError)(t) || (0, c.isDynamicServerError)(t) || (0, i.isDynamicPostpone)(t) || (0, o.isPostpone)(t) || (0, n.isHangingPromiseRejectionError)(t) || (0, i.isPrerenderInterruptedError)(t)) throw t;
                t instanceof Error && "cause" in t && e(t.cause)
            }
        }
    });
    let n = e.r(38747),
        o = e.r(56465),
        a = e.r(85635),
        u = e.r(75682),
        i = e.r(34070),
        c = e.r(29123);
    ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 59366, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "unstable_rethrow", {
        enumerable: !0,
        get: function() {
            return n
        }
    });
    let n = "u" < typeof window ? e.r(61298).unstable_rethrow : e.r(40211).unstable_rethrow;
    ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 12706, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        ReadonlyURLSearchParams: function() {
            return a.ReadonlyURLSearchParams
        },
        RedirectType: function() {
            return i.RedirectType
        },
        forbidden: function() {
            return s.forbidden
        },
        notFound: function() {
            return c.notFound
        },
        permanentRedirect: function() {
            return u.permanentRedirect
        },
        redirect: function() {
            return u.redirect
        },
        unauthorized: function() {
            return l.unauthorized
        },
        unstable_isUnrecognizedActionError: function() {
            return f
        },
        unstable_rethrow: function() {
            return d.unstable_rethrow
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });
    let a = e.r(75159),
        u = e.r(15539),
        i = e.r(26204),
        c = e.r(93703),
        s = e.r(82526),
        l = e.r(87206),
        d = e.r(59366);

    function f() {
        throw Object.defineProperty(Error("`unstable_isUnrecognizedActionError` can only be used on the client."), "__NEXT_ERROR_CODE", {
            value: "E776",
            enumerable: !1,
            configurable: !0
        })
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 37109, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        ReadonlyURLSearchParams: function() {
            return i.ReadonlyURLSearchParams
        },
        RedirectType: function() {
            return d.RedirectType
        },
        ServerInsertedHTMLContext: function() {
            return s.ServerInsertedHTMLContext
        },
        forbidden: function() {
            return d.forbidden
        },
        notFound: function() {
            return d.notFound
        },
        permanentRedirect: function() {
            return d.permanentRedirect
        },
        redirect: function() {
            return d.redirect
        },
        unauthorized: function() {
            return d.unauthorized
        },
        unstable_isUnrecognizedActionError: function() {
            return l.unstable_isUnrecognizedActionError
        },
        unstable_rethrow: function() {
            return d.unstable_rethrow
        },
        useParams: function() {
            return h
        },
        usePathname: function() {
            return _
        },
        useRouter: function() {
            return m
        },
        useSearchParams: function() {
            return y
        },
        useSelectedLayoutSegment: function() {
            return E
        },
        useSelectedLayoutSegments: function() {
            return b
        },
        useServerInsertedHTML: function() {
            return s.useServerInsertedHTML
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });
    let a = e.r(44066)._(e.r(44440)),
        u = e.r(31270),
        i = e.r(65663),
        c = e.r(2019),
        s = e.r(24857),
        l = e.r(51878),
        d = e.r(12706),
        f = "u" < typeof window ? e.r(34070).useDynamicRouteParams : void 0,
        p = "u" < typeof window ? e.r(34070).useDynamicSearchParams : void 0;

    function y() {
        p ? .("useSearchParams()");
        let e = (0, a.useContext)(i.SearchParamsContext);
        return (0, a.useMemo)(() => e ? new i.ReadonlyURLSearchParams(e) : null, [e])
    }

    function _() {
        return f ? .("usePathname()"), (0, a.useContext)(i.PathnameContext)
    }

    function m() {
        let e = (0, a.useContext)(u.AppRouterContext);
        if (null === e) throw Object.defineProperty(Error("invariant expected app router to be mounted"), "__NEXT_ERROR_CODE", {
            value: "E238",
            enumerable: !1,
            configurable: !0
        });
        return e
    }

    function h() {
        return f ? .("useParams()"), (0, a.useContext)(i.PathParamsContext)
    }

    function b(e = "children") {
        f ? .("useSelectedLayoutSegments()");
        let t = (0, a.useContext)(u.LayoutRouterContext);
        return t ? (0, c.getSelectedLayoutSegmentPath)(t.parentTree, e) : null
    }

    function E(e = "children") {
        f ? .("useSelectedLayoutSegment()"), (0, a.useContext)(i.NavigationPromisesContext);
        let t = b(e);
        return (0, c.computeSelectedLayoutSegment)(t, e)
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}]);