(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 45694, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "warnOnce", {
        enumerable: !0,
        get: function() {
            return n
        }
    });
    let n = e => {}
}, 28919, (e, t, r) => {
    "use strict";

    function n(e, t = {}) {
        if (t.onlyHashChange) return void e();
        let r = document.documentElement;
        if ("smooth" !== r.dataset.scrollBehavior) return void e();
        let a = r.style.scrollBehavior;
        r.style.scrollBehavior = "auto", t.dontForceLayout || r.getClientRects(), e(), r.style.scrollBehavior = a
    }
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "disableSmoothScrollDuringRouteTransition", {
        enumerable: !0,
        get: function() {
            return n
        }
    }), e.r(45694)
}, 93487, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "HTTPAccessFallbackBoundary", {
        enumerable: !0,
        get: function() {
            return l
        }
    });
    let n = e.r(44066),
        a = e.r(87433),
        o = n._(e.r(44440)),
        i = e.r(46088),
        s = e.r(58029);
    e.r(45694);
    let c = e.r(31270);
    class u extends o.default.Component {
        constructor(e) {
            super(e), this.state = {
                triggeredStatus: void 0,
                previousPathname: e.pathname
            }
        }
        componentDidCatch() {}
        static getDerivedStateFromError(e) {
            if ((0, s.isHTTPAccessFallbackError)(e)) return {
                triggeredStatus: (0, s.getAccessFallbackHTTPStatus)(e)
            };
            throw e
        }
        static getDerivedStateFromProps(e, t) {
            return e.pathname !== t.previousPathname && t.triggeredStatus ? {
                triggeredStatus: void 0,
                previousPathname: e.pathname
            } : {
                triggeredStatus: t.triggeredStatus,
                previousPathname: e.pathname
            }
        }
        render() {
            let {
                notFound: e,
                forbidden: t,
                unauthorized: r,
                children: n
            } = this.props, {
                triggeredStatus: o
            } = this.state, i = {
                [s.HTTPAccessErrorStatus.NOT_FOUND]: e,
                [s.HTTPAccessErrorStatus.FORBIDDEN]: t,
                [s.HTTPAccessErrorStatus.UNAUTHORIZED]: r
            };
            if (o) {
                let c = o === s.HTTPAccessErrorStatus.NOT_FOUND && e,
                    u = o === s.HTTPAccessErrorStatus.FORBIDDEN && t,
                    l = o === s.HTTPAccessErrorStatus.UNAUTHORIZED && r;
                return c || u || l ? (0, a.jsxs)(a.Fragment, {
                    children: [(0, a.jsx)("meta", {
                        name: "robots",
                        content: "noindex"
                    }), !1, i[o]]
                }) : n
            }
            return n
        }
    }

    function l({
        notFound: e,
        forbidden: t,
        unauthorized: r,
        children: n
    }) {
        let s = (0, i.useUntrackedPathname)(),
            l = (0, o.useContext)(c.MissingSlotContext);
        return e || t || r ? (0, a.jsx)(u, {
            pathname: s,
            notFound: e,
            forbidden: t,
            unauthorized: r,
            missingSlots: l,
            children: n
        }) : (0, a.jsx)(a.Fragment, {
            children: n
        })
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 26890, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "useRouterBFCache", {
        enumerable: !0,
        get: function() {
            return a
        }
    });
    let n = e.r(44440);

    function a(e, t) {
        let [r, a] = (0, n.useState)(() => ({
            tree: e,
            stateKey: t,
            next: null
        }));
        if (r.tree === e) return r;
        let o = {
                tree: e,
                stateKey: t,
                next: null
            },
            i = 1,
            s = r,
            c = o;
        for (; null !== s && i < 1;) {
            if (s.stateKey === t) {
                c.next = s.next;
                break
            } {
                i++;
                let e = {
                    tree: s.tree,
                    stateKey: s.stateKey,
                    next: null
                };
                c.next = e, c = e
            }
            s = s.next
        }
        return a(o), o
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 45121, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "default", {
        enumerable: !0,
        get: function() {
            return w
        }
    });
    let n = e.r(81258),
        a = e.r(44066),
        o = e.r(87433),
        i = a._(e.r(44440)),
        s = n._(e.r(65596)),
        c = e.r(31270),
        u = e.r(84883),
        l = e.r(2490),
        d = e.r(76078),
        f = e.r(28919),
        p = e.r(16304),
        h = e.r(93487),
        m = e.r(95913),
        g = e.r(26890);
    e.r(11720);
    let y = e.r(65663),
        b = e.r(26883),
        P = e.r(40664),
        _ = s.default.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,
        S = ["bottom", "height", "left", "right", "top", "width", "x", "y"];

    function v(e, t) {
        let r = e.getBoundingClientRect();
        return r.top >= 0 && r.top <= t
    }
    class O extends i.default.Component {
        componentDidMount() {
            this.handlePotentialScroll()
        }
        componentDidUpdate() {
            this.props.focusAndScrollRef.apply && this.handlePotentialScroll()
        }
        render() {
            return this.props.children
        }
        constructor(...e) {
            super(...e), this.handlePotentialScroll = () => {
                let {
                    focusAndScrollRef: e,
                    segmentPath: t
                } = this.props;
                if (e.apply) {
                    if (0 !== e.segmentPaths.length && !e.segmentPaths.some(e => t.every((t, r) => (0, d.matchSegment)(t, e[r])))) return;
                    let r = null,
                        n = e.hashFragment;
                    if (n && (r = "top" === n ? document.body : document.getElementById(n) ? ? document.getElementsByName(n)[0]), r || (r = "u" < typeof window ? null : (0, _.findDOMNode)(this)), !(r instanceof Element)) return;
                    for (; !(r instanceof HTMLElement) || function(e) {
                            if (["sticky", "fixed"].includes(getComputedStyle(e).position)) return !0;
                            let t = e.getBoundingClientRect();
                            return S.every(e => 0 === t[e])
                        }(r);) {
                        if (null === r.nextElementSibling) return;
                        r = r.nextElementSibling
                    }
                    e.apply = !1, e.hashFragment = null, e.segmentPaths = [], (0, f.disableSmoothScrollDuringRouteTransition)(() => {
                        if (n) return void r.scrollIntoView();
                        let e = document.documentElement,
                            t = e.clientHeight;
                        !v(r, t) && (e.scrollTop = 0, v(r, t) || r.scrollIntoView())
                    }, {
                        dontForceLayout: !0,
                        onlyHashChange: e.onlyHashChange
                    }), e.onlyHashChange = !1, r.focus()
                }
            }
        }
    }

    function R({
        segmentPath: e,
        children: t
    }) {
        let r = (0, i.useContext)(c.GlobalLayoutRouterContext);
        if (!r) throw Object.defineProperty(Error("invariant global layout router not mounted"), "__NEXT_ERROR_CODE", {
            value: "E473",
            enumerable: !1,
            configurable: !0
        });
        return (0, o.jsx)(O, {
            segmentPath: e,
            focusAndScrollRef: r.focusAndScrollRef,
            children: t
        })
    }

    function E({
        tree: e,
        segmentPath: t,
        debugNameContext: r,
        cacheNode: n,
        params: a,
        url: s,
        isActive: l
    }) {
        let d, f = (0, i.useContext)(c.GlobalLayoutRouterContext);
        if ((0, i.useContext)(y.NavigationPromisesContext), !f) throw Object.defineProperty(Error("invariant global layout router not mounted"), "__NEXT_ERROR_CODE", {
            value: "E473",
            enumerable: !1,
            configurable: !0
        });
        let p = null !== n ? n : (0, i.use)(u.unresolvedThenable),
            h = null !== p.prefetchRsc ? p.prefetchRsc : p.rsc,
            m = (0, i.useDeferredValue)(p.rsc, h);
        if ((0, P.isDeferredRsc)(m)) {
            let e = (0, i.use)(m);
            null === e && (0, i.use)(u.unresolvedThenable), d = e
        } else null === m && (0, i.use)(u.unresolvedThenable), d = m;
        let g = d;
        return (0, o.jsx)(c.LayoutRouterContext.Provider, {
            value: {
                parentTree: e,
                parentCacheNode: p,
                parentSegmentPath: t,
                parentParams: a,
                debugNameContext: r,
                url: s,
                isActive: l
            },
            children: g
        })
    }

    function j({
        name: e,
        loading: t,
        children: r
    }) {
        let n;
        if (n = "object" == typeof t && null !== t && "function" == typeof t.then ? (0, i.use)(t) : t) {
            let t = n[0],
                a = n[1],
                s = n[2];
            return (0, o.jsx)(i.Suspense, {
                name: e,
                fallback: (0, o.jsxs)(o.Fragment, {
                    children: [a, s, t]
                }),
                children: r
            })
        }
        return (0, o.jsx)(o.Fragment, {
            children: r
        })
    }

    function w({
        parallelRouterKey: e,
        error: t,
        errorStyles: r,
        errorScripts: n,
        templateStyles: a,
        templateScripts: s,
        template: d,
        notFound: f,
        forbidden: y,
        unauthorized: P,
        segmentViewBoundaries: _
    }) {
        let S = (0, i.useContext)(c.LayoutRouterContext);
        if (!S) throw Object.defineProperty(Error("invariant expected layout router to be mounted"), "__NEXT_ERROR_CODE", {
            value: "E56",
            enumerable: !1,
            configurable: !0
        });
        let {
            parentTree: v,
            parentCacheNode: O,
            parentSegmentPath: w,
            parentParams: C,
            url: T,
            isActive: x,
            debugNameContext: A
        } = S, M = O.parallelRoutes, D = M.get(e);
        D || (D = new Map, M.set(e, D));
        let F = v[0],
            I = null === w ? [e] : w.concat([F, e]),
            k = v[1][e];
        void 0 === k && (0, i.use)(u.unresolvedThenable);
        let N = k[0],
            U = (0, m.createRouterCacheKey)(N, !0),
            B = (0, g.useRouterBFCache)(k, U),
            L = [];
        do {
            let e = B.tree,
                i = B.stateKey,
                u = e[0],
                g = (0, m.createRouterCacheKey)(u),
                _ = D.get(g) ? ? null,
                S = C;
            if (Array.isArray(u)) {
                let e = u[0],
                    t = u[1],
                    r = u[2],
                    n = (0, b.getParamValueFromCacheKey)(t, r);
                null !== n && (S = { ...C,
                    [e]: n
                })
            }
            let v = function(e) {
                    if ("/" === e) return "/";
                    if ("string" == typeof e)
                        if ("(slot)" === e) return;
                        else return e + "/";
                    return e[1] + "/"
                }(u),
                w = v ? ? A,
                M = void 0 === v ? void 0 : A,
                F = O.loading,
                k = (0, o.jsxs)(c.TemplateContext.Provider, {
                    value: (0, o.jsxs)(R, {
                        segmentPath: I,
                        children: [(0, o.jsx)(l.ErrorBoundary, {
                            errorComponent: t,
                            errorStyles: r,
                            errorScripts: n,
                            children: (0, o.jsx)(j, {
                                name: M,
                                loading: F,
                                children: (0, o.jsx)(h.HTTPAccessFallbackBoundary, {
                                    notFound: f,
                                    forbidden: y,
                                    unauthorized: P,
                                    children: (0, o.jsxs)(p.RedirectBoundary, {
                                        children: [(0, o.jsx)(E, {
                                            url: T,
                                            tree: e,
                                            params: S,
                                            cacheNode: _,
                                            segmentPath: I,
                                            debugNameContext: w,
                                            isActive: x && i === U
                                        }), null]
                                    })
                                })
                            })
                        }), null]
                    }),
                    children: [a, s, d]
                }, i);
            L.push(k), B = B.next
        } while (null !== B) return L
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 60512, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "default", {
        enumerable: !0,
        get: function() {
            return s
        }
    });
    let n = e.r(44066),
        a = e.r(87433),
        o = n._(e.r(44440)),
        i = e.r(31270);

    function s() {
        let e = (0, o.useContext)(i.TemplateContext);
        return (0, a.jsx)(a.Fragment, {
            children: e
        })
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 57458, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "createRenderSearchParamsFromClient", {
        enumerable: !0,
        get: function() {
            return a
        }
    });
    let n = new WeakMap;

    function a(e) {
        let t = n.get(e);
        if (t) return t;
        let r = Promise.resolve(e);
        return n.set(e, r), r
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 6763, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "createRenderSearchParamsFromClient", {
        enumerable: !0,
        get: function() {
            return n
        }
    });
    let n = e.r(57458).createRenderSearchParamsFromClient;
    ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 4257, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "createRenderParamsFromClient", {
        enumerable: !0,
        get: function() {
            return a
        }
    });
    let n = new WeakMap;

    function a(e) {
        let t = n.get(e);
        if (t) return t;
        let r = Promise.resolve(e);
        return n.set(e, r), r
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 15735, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "createRenderParamsFromClient", {
        enumerable: !0,
        get: function() {
            return n
        }
    });
    let n = e.r(4257).createRenderParamsFromClient;
    ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 39731, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "ReflectAdapter", {
        enumerable: !0,
        get: function() {
            return n
        }
    });
    class n {
        static get(e, t, r) {
            let n = Reflect.get(e, t, r);
            return "function" == typeof n ? n.bind(e) : n
        }
        static set(e, t, r, n) {
            return Reflect.set(e, t, r, n)
        }
        static has(e, t) {
            return Reflect.has(e, t)
        }
        static deleteProperty(e, t) {
            return Reflect.deleteProperty(e, t)
        }
    }
}, 31630, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "createDedupedByCallsiteServerErrorLoggerDev", {
        enumerable: !0,
        get: function() {
            return c
        }
    });
    let n = function(e, t) {
        if (e && e.__esModule) return e;
        if (null === e || "object" != typeof e && "function" != typeof e) return {
            default: e
        };
        var r = a(void 0);
        if (r && r.has(e)) return r.get(e);
        var n = {
                __proto__: null
            },
            o = Object.defineProperty && Object.getOwnPropertyDescriptor;
        for (var i in e)
            if ("default" !== i && Object.prototype.hasOwnProperty.call(e, i)) {
                var s = o ? Object.getOwnPropertyDescriptor(e, i) : null;
                s && (s.get || s.set) ? Object.defineProperty(n, i, s) : n[i] = e[i]
            }
        return n.default = e, r && r.set(e, n), n
    }(e.r(44440));

    function a(e) {
        if ("function" != typeof WeakMap) return null;
        var t = new WeakMap,
            r = new WeakMap;
        return (a = function(e) {
            return e ? r : t
        })(e)
    }
    let o = {
            current: null
        },
        i = "function" == typeof n.cache ? n.cache : e => e,
        s = console.warn;

    function c(e) {
        return function(...t) {
            s(e(...t))
        }
    }
    i(e => {
        try {
            s(o.current)
        } finally {
            o.current = null
        }
    })
}, 80099, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        describeHasCheckingStringProperty: function() {
            return s
        },
        describeStringPropertyAccess: function() {
            return i
        },
        wellKnownProperties: function() {
            return c
        }
    };
    for (var a in n) Object.defineProperty(r, a, {
        enumerable: !0,
        get: n[a]
    });
    let o = /^[A-Za-z_$][A-Za-z0-9_$]*$/;

    function i(e, t) {
        return o.test(t) ? `\`${e}.${t}\`` : `\`${e}[${JSON.stringify(t)}]\``
    }

    function s(e, t) {
        let r = JSON.stringify(t);
        return `\`Reflect.has(${e}, ${r})\`, \`${r} in ${e}\`, or similar`
    }
    let c = new Set(["hasOwnProperty", "isPrototypeOf", "propertyIsEnumerable", "toString", "valueOf", "toLocaleString", "then", "catch", "finally", "status", "displayName", "_debugInfo", "toJSON", "$$typeof", "__esModule"])
}, 67492, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "afterTaskAsyncStorageInstance", {
        enumerable: !0,
        get: function() {
            return n
        }
    });
    let n = (0, e.r(60721).createAsyncLocalStorage)()
}, 17803, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "afterTaskAsyncStorage", {
        enumerable: !0,
        get: function() {
            return n.afterTaskAsyncStorageInstance
        }
    });
    let n = e.r(67492)
}, 3446, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        isRequestAPICallableInsideAfter: function() {
            return u
        },
        throwForSearchParamsAccessInUseCache: function() {
            return c
        },
        throwWithStaticGenerationBailoutErrorWithDynamicError: function() {
            return s
        }
    };
    for (var a in n) Object.defineProperty(r, a, {
        enumerable: !0,
        get: n[a]
    });
    let o = e.r(95238),
        i = e.r(17803);

    function s(e, t) {
        throw Object.defineProperty(new o.StaticGenBailoutError(`Route ${e} with \`dynamic = "error"\` couldn't be rendered statically because it used ${t}. See more info here: https://nextjs.org/docs/app/building-your-application/rendering/static-and-dynamic#dynamic-rendering`), "__NEXT_ERROR_CODE", {
            value: "E543",
            enumerable: !1,
            configurable: !0
        })
    }

    function c(e, t) {
        let r = Object.defineProperty(Error(`Route ${e.route} used \`searchParams\` inside "use cache". Accessing dynamic request data inside a cache scope is not supported. If you need some search params inside a cached function await \`searchParams\` outside of the cached function and pass only the required search params as arguments to the cached function. See more info here: https://nextjs.org/docs/messages/next-request-in-use-cache`), "__NEXT_ERROR_CODE", {
            value: "E842",
            enumerable: !1,
            configurable: !0
        });
        throw Error.captureStackTrace(r, t), e.invalidDynamicUsageError ? ? = r, r
    }

    function u() {
        let e = i.afterTaskAsyncStorage.getStore();
        return (null == e ? void 0 : e.rootTaskSpawnPhase) === "action"
    }
}, 53471, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n, a = {
        RenderStage: function() {
            return c
        },
        StagedRenderingController: function() {
            return u
        }
    };
    for (var o in a) Object.defineProperty(r, o, {
        enumerable: !0,
        get: a[o]
    });
    let i = e.r(28933),
        s = e.r(24586);
    var c = ((n = {})[n.Before = 1] = "Before", n[n.Static = 2] = "Static", n[n.Runtime = 3] = "Runtime", n[n.Dynamic = 4] = "Dynamic", n[n.Abandoned = 5] = "Abandoned", n);
    class u {
        constructor(e = null, t) {
            this.abortSignal = e, this.hasRuntimePrefetch = t, this.currentStage = 1, this.staticInterruptReason = null, this.runtimeInterruptReason = null, this.staticStageEndTime = 1 / 0, this.runtimeStageEndTime = 1 / 0, this.runtimeStageListeners = [], this.dynamicStageListeners = [], this.runtimeStagePromise = (0, s.createPromiseWithResolvers)(), this.dynamicStagePromise = (0, s.createPromiseWithResolvers)(), this.mayAbandon = !1, e && (e.addEventListener("abort", () => {
                let {
                    reason: t
                } = e;
                this.currentStage < 3 && (this.runtimeStagePromise.promise.catch(l), this.runtimeStagePromise.reject(t)), (this.currentStage < 4 || 5 === this.currentStage) && (this.dynamicStagePromise.promise.catch(l), this.dynamicStagePromise.reject(t))
            }, {
                once: !0
            }), this.mayAbandon = !0)
        }
        onStage(e, t) {
            if (this.currentStage >= e) t();
            else if (3 === e) this.runtimeStageListeners.push(t);
            else if (4 === e) this.dynamicStageListeners.push(t);
            else throw Object.defineProperty(new i.InvariantError(`Invalid render stage: ${e}`), "__NEXT_ERROR_CODE", {
                value: "E881",
                enumerable: !1,
                configurable: !0
            })
        }
        canSyncInterrupt() {
            if (1 === this.currentStage) return !1;
            let e = this.hasRuntimePrefetch ? 4 : 3;
            return this.currentStage < e
        }
        syncInterruptCurrentStageWithReason(e) {
            if (1 !== this.currentStage) {
                if (this.mayAbandon) return this.abandonRenderImpl();
                switch (this.currentStage) {
                    case 2:
                        this.staticInterruptReason = e, this.advanceStage(4);
                        return;
                    case 3:
                        this.hasRuntimePrefetch && (this.runtimeInterruptReason = e, this.advanceStage(4));
                        return
                }
            }
        }
        getStaticInterruptReason() {
            return this.staticInterruptReason
        }
        getRuntimeInterruptReason() {
            return this.runtimeInterruptReason
        }
        getStaticStageEndTime() {
            return this.staticStageEndTime
        }
        getRuntimeStageEndTime() {
            return this.runtimeStageEndTime
        }
        abandonRender() {
            if (!this.mayAbandon) throw Object.defineProperty(new i.InvariantError("`abandonRender` called on a stage controller that cannot be abandoned."), "__NEXT_ERROR_CODE", {
                value: "E938",
                enumerable: !1,
                configurable: !0
            });
            this.abandonRenderImpl()
        }
        abandonRenderImpl() {
            let {
                currentStage: e
            } = this;
            switch (e) {
                case 2:
                    this.currentStage = 5, this.resolveRuntimeStage();
                    return;
                case 3:
                    this.currentStage = 5;
                    return
            }
        }
        advanceStage(e) {
            if (e <= this.currentStage) return;
            let t = this.currentStage;
            if (this.currentStage = e, t < 3 && e >= 3 && (this.staticStageEndTime = performance.now() + performance.timeOrigin, this.resolveRuntimeStage()), t < 4 && e >= 4) {
                this.runtimeStageEndTime = performance.now() + performance.timeOrigin, this.resolveDynamicStage();
                return
            }
        }
        resolveRuntimeStage() {
            let e = this.runtimeStageListeners;
            for (let t = 0; t < e.length; t++) e[t]();
            e.length = 0, this.runtimeStagePromise.resolve()
        }
        resolveDynamicStage() {
            let e = this.dynamicStageListeners;
            for (let t = 0; t < e.length; t++) e[t]();
            e.length = 0, this.dynamicStagePromise.resolve()
        }
        getStagePromise(e) {
            switch (e) {
                case 3:
                    return this.runtimeStagePromise.promise;
                case 4:
                    return this.dynamicStagePromise.promise;
                default:
                    throw Object.defineProperty(new i.InvariantError(`Invalid render stage: ${e}`), "__NEXT_ERROR_CODE", {
                        value: "E881",
                        enumerable: !1,
                        configurable: !0
                    })
            }
        }
        waitForStage(e) {
            return this.getStagePromise(e)
        }
        delayUntilStage(e, t, r) {
            var n, a, o;
            let i, s = (n = this.getStagePromise(e), a = t, o = r, i = new Promise((e, t) => {
                n.then(e.bind(null, o), t)
            }), void 0 !== a && (i.displayName = a), i);
            return this.abortSignal && s.catch(l), s
        }
    }

    function l() {}
}, 52772, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        createPrerenderSearchParamsForClientPage: function() {
            return g
        },
        createSearchParamsFromClient: function() {
            return p
        },
        createServerSearchParamsForMetadata: function() {
            return h
        },
        createServerSearchParamsForServerPage: function() {
            return m
        },
        makeErroringSearchParamsForUseCache: function() {
            return S
        }
    };
    for (var a in n) Object.defineProperty(r, a, {
        enumerable: !0,
        get: n[a]
    });
    let o = e.r(39731),
        i = e.r(34070),
        s = e.r(72786),
        c = e.r(28933),
        u = e.r(38747),
        l = e.r(31630),
        d = e.r(80099),
        f = e.r(3446);

    function p(e, t) {
        let r = s.workUnitAsyncStorage.getStore();
        if (r) switch (r.type) {
            case "prerender":
            case "prerender-client":
            case "prerender-ppr":
            case "prerender-legacy":
                return y(t, r);
            case "prerender-runtime":
                throw Object.defineProperty(new c.InvariantError("createSearchParamsFromClient should not be called in a runtime prerender."), "__NEXT_ERROR_CODE", {
                    value: "E769",
                    enumerable: !1,
                    configurable: !0
                });
            case "cache":
            case "private-cache":
            case "unstable-cache":
                throw Object.defineProperty(new c.InvariantError("createSearchParamsFromClient should not be called in cache contexts."), "__NEXT_ERROR_CODE", {
                    value: "E739",
                    enumerable: !1,
                    configurable: !0
                });
            case "request":
                return b(e, t, r)
        }(0, s.throwInvariantForMissingStore)()
    }
    e.r(53471);
    let h = m;

    function m(e, t) {
        let r = s.workUnitAsyncStorage.getStore();
        if (r) switch (r.type) {
            case "prerender":
            case "prerender-client":
            case "prerender-ppr":
            case "prerender-legacy":
                return y(t, r);
            case "cache":
            case "private-cache":
            case "unstable-cache":
                throw Object.defineProperty(new c.InvariantError("createServerSearchParamsForServerPage should not be called in cache contexts."), "__NEXT_ERROR_CODE", {
                    value: "E747",
                    enumerable: !1,
                    configurable: !0
                });
            case "prerender-runtime":
                var n, a;
                return n = e, a = r, (0, i.delayUntilRuntimeStage)(a, v(n));
            case "request":
                return b(e, t, r)
        }(0, s.throwInvariantForMissingStore)()
    }

    function g(e) {
        if (e.forceStatic) return Promise.resolve({});
        let t = s.workUnitAsyncStorage.getStore();
        if (t) switch (t.type) {
            case "prerender":
            case "prerender-client":
                return (0, u.makeHangingPromise)(t.renderSignal, e.route, "`searchParams`");
            case "prerender-runtime":
                throw Object.defineProperty(new c.InvariantError("createPrerenderSearchParamsForClientPage should not be called in a runtime prerender."), "__NEXT_ERROR_CODE", {
                    value: "E768",
                    enumerable: !1,
                    configurable: !0
                });
            case "cache":
            case "private-cache":
            case "unstable-cache":
                throw Object.defineProperty(new c.InvariantError("createPrerenderSearchParamsForClientPage should not be called in cache contexts."), "__NEXT_ERROR_CODE", {
                    value: "E746",
                    enumerable: !1,
                    configurable: !0
                });
            case "prerender-ppr":
            case "prerender-legacy":
            case "request":
                return Promise.resolve({})
        }(0, s.throwInvariantForMissingStore)()
    }

    function y(e, t) {
        if (e.forceStatic) return Promise.resolve({});
        switch (t.type) {
            case "prerender":
            case "prerender-client":
                var r = e,
                    n = t;
                let a = P.get(n);
                if (a) return a;
                let s = (0, u.makeHangingPromise)(n.renderSignal, r.route, "`searchParams`"),
                    c = new Proxy(s, {
                        get(e, t, r) {
                            if (Object.hasOwn(s, t)) return o.ReflectAdapter.get(e, t, r);
                            switch (t) {
                                case "then":
                                    return (0, i.annotateDynamicAccess)("`await searchParams`, `searchParams.then`, or similar", n), o.ReflectAdapter.get(e, t, r);
                                case "status":
                                    return (0, i.annotateDynamicAccess)("`use(searchParams)`, `searchParams.status`, or similar", n), o.ReflectAdapter.get(e, t, r);
                                default:
                                    return o.ReflectAdapter.get(e, t, r)
                            }
                        }
                    });
                return P.set(n, c), c;
            case "prerender-ppr":
            case "prerender-legacy":
                var l = e,
                    d = t;
                let p = P.get(l);
                if (p) return p;
                let h = Promise.resolve({}),
                    m = new Proxy(h, {
                        get(e, t, r) {
                            if (Object.hasOwn(h, t)) return o.ReflectAdapter.get(e, t, r);
                            if ("string" == typeof t && "then" === t) {
                                let e = "`await searchParams`, `searchParams.then`, or similar";
                                l.dynamicShouldError ? (0, f.throwWithStaticGenerationBailoutErrorWithDynamicError)(l.route, e) : "prerender-ppr" === d.type ? (0, i.postponeWithTracking)(l.route, e, d.dynamicTracking) : (0, i.throwToInterruptStaticGeneration)(e, l, d)
                            }
                            return o.ReflectAdapter.get(e, t, r)
                        }
                    });
                return P.set(l, m), m;
            default:
                return t
        }
    }

    function b(e, t, r) {
        return t.forceStatic ? Promise.resolve({}) : v(e)
    }
    let P = new WeakMap,
        _ = new WeakMap;

    function S(e) {
        let t = _.get(e);
        if (t) return t;
        let r = Promise.resolve({}),
            n = new Proxy(r, {
                get: function t(n, a, i) {
                    return Object.hasOwn(r, a) || "string" != typeof a || "then" !== a && d.wellKnownProperties.has(a) || (0, f.throwForSearchParamsAccessInUseCache)(e, t), o.ReflectAdapter.get(n, a, i)
                }
            });
        return _.set(e, n), n
    }

    function v(e) {
        let t = P.get(e);
        if (t) return t;
        let r = Promise.resolve(e);
        return P.set(e, r), r
    }(0, l.createDedupedByCallsiteServerErrorLoggerDev)(function(e, t) {
        let r = e ? `Route "${e}" ` : "This route ";
        return Object.defineProperty(Error(`${r}used ${t}. \`searchParams\` is a Promise and must be unwrapped with \`await\` or \`React.use()\` before accessing its properties. Learn more: https://nextjs.org/docs/messages/sync-dynamic-apis`), "__NEXT_ERROR_CODE", {
            value: "E848",
            enumerable: !1,
            configurable: !0
        })
    })
}, 84599, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "dynamicAccessAsyncStorageInstance", {
        enumerable: !0,
        get: function() {
            return n
        }
    });
    let n = (0, e.r(60721).createAsyncLocalStorage)()
}, 69804, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "dynamicAccessAsyncStorage", {
        enumerable: !0,
        get: function() {
            return n.dynamicAccessAsyncStorageInstance
        }
    });
    let n = e.r(84599)
}, 87468, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        createParamsFromClient: function() {
            return h
        },
        createPrerenderParamsForClientSegment: function() {
            return b
        },
        createServerParamsForMetadata: function() {
            return m
        },
        createServerParamsForRoute: function() {
            return g
        },
        createServerParamsForServerSegment: function() {
            return y
        }
    };
    for (var a in n) Object.defineProperty(r, a, {
        enumerable: !0,
        get: n[a]
    });
    let o = e.r(42907),
        i = e.r(39731),
        s = e.r(34070),
        c = e.r(72786),
        u = e.r(28933),
        l = e.r(80099),
        d = e.r(38747),
        f = e.r(31630),
        p = e.r(69804);

    function h(e, t) {
        let r = c.workUnitAsyncStorage.getStore();
        if (r) switch (r.type) {
            case "prerender":
            case "prerender-client":
            case "prerender-ppr":
            case "prerender-legacy":
                return P(e, t, r);
            case "cache":
            case "private-cache":
            case "unstable-cache":
                throw Object.defineProperty(new u.InvariantError("createParamsFromClient should not be called in cache contexts."), "__NEXT_ERROR_CODE", {
                    value: "E736",
                    enumerable: !1,
                    configurable: !0
                });
            case "prerender-runtime":
                throw Object.defineProperty(new u.InvariantError("createParamsFromClient should not be called in a runtime prerender."), "__NEXT_ERROR_CODE", {
                    value: "E770",
                    enumerable: !1,
                    configurable: !0
                });
            case "request":
                return O(e)
        }(0, c.throwInvariantForMissingStore)()
    }
    e.r(53471);
    let m = y;

    function g(e, t) {
        let r = c.workUnitAsyncStorage.getStore();
        if (r) switch (r.type) {
            case "prerender":
            case "prerender-client":
            case "prerender-ppr":
            case "prerender-legacy":
                return P(e, t, r);
            case "cache":
            case "private-cache":
            case "unstable-cache":
                throw Object.defineProperty(new u.InvariantError("createServerParamsForRoute should not be called in cache contexts."), "__NEXT_ERROR_CODE", {
                    value: "E738",
                    enumerable: !1,
                    configurable: !0
                });
            case "prerender-runtime":
                return _(e, r);
            case "request":
                return O(e)
        }(0, c.throwInvariantForMissingStore)()
    }

    function y(e, t) {
        let r = c.workUnitAsyncStorage.getStore();
        if (r) switch (r.type) {
            case "prerender":
            case "prerender-client":
            case "prerender-ppr":
            case "prerender-legacy":
                return P(e, t, r);
            case "cache":
            case "private-cache":
            case "unstable-cache":
                throw Object.defineProperty(new u.InvariantError("createServerParamsForServerSegment should not be called in cache contexts."), "__NEXT_ERROR_CODE", {
                    value: "E743",
                    enumerable: !1,
                    configurable: !0
                });
            case "prerender-runtime":
                return _(e, r);
            case "request":
                return O(e)
        }(0, c.throwInvariantForMissingStore)()
    }

    function b(e) {
        let t = o.workAsyncStorage.getStore();
        if (!t) throw Object.defineProperty(new u.InvariantError("Missing workStore in createPrerenderParamsForClientSegment"), "__NEXT_ERROR_CODE", {
            value: "E773",
            enumerable: !1,
            configurable: !0
        });
        let r = c.workUnitAsyncStorage.getStore();
        if (r) switch (r.type) {
            case "prerender":
            case "prerender-client":
                let n = r.fallbackRouteParams;
                if (n) {
                    for (let a in e)
                        if (n.has(a)) return (0, d.makeHangingPromise)(r.renderSignal, t.route, "`params`")
                }
                break;
            case "cache":
            case "private-cache":
            case "unstable-cache":
                throw Object.defineProperty(new u.InvariantError("createPrerenderParamsForClientSegment should not be called in cache contexts."), "__NEXT_ERROR_CODE", {
                    value: "E734",
                    enumerable: !1,
                    configurable: !0
                })
        }
        return Promise.resolve(e)
    }

    function P(e, t, r) {
        switch (r.type) {
            case "prerender":
            case "prerender-client":
                {
                    let n = r.fallbackRouteParams;
                    if (n) {
                        for (let a in e)
                            if (n.has(a)) return function(e, t, r) {
                                let n = S.get(e);
                                if (n) return n;
                                let a = new Proxy((0, d.makeHangingPromise)(r.renderSignal, t.route, "`params`"), v);
                                return S.set(e, a), a
                            }(e, t, r)
                    }
                    break
                }
            case "prerender-ppr":
                {
                    let n = r.fallbackRouteParams;
                    if (n) {
                        for (let a in e)
                            if (n.has(a)) return function(e, t, r, n) {
                                let a = S.get(e);
                                if (a) return a;
                                let o = { ...e
                                    },
                                    i = Promise.resolve(o);
                                return S.set(e, i), Object.keys(e).forEach(e => {
                                    l.wellKnownProperties.has(e) || t.has(e) && Object.defineProperty(o, e, {
                                        get() {
                                            let t = (0, l.describeStringPropertyAccess)("params", e);
                                            "prerender-ppr" === n.type ? (0, s.postponeWithTracking)(r.route, t, n.dynamicTracking) : (0, s.throwToInterruptStaticGeneration)(t, r, n)
                                        },
                                        enumerable: !0
                                    })
                                }), i
                            }(e, n, t, r)
                    }
                }
        }
        return O(e)
    }

    function _(e, t) {
        return (0, s.delayUntilRuntimeStage)(t, O(e))
    }
    let S = new WeakMap,
        v = {
            get: function(e, t, r) {
                if ("then" === t || "catch" === t || "finally" === t) {
                    let n = i.ReflectAdapter.get(e, t, r);
                    return ({
                        [t]: (...t) => {
                            let r = p.dynamicAccessAsyncStorage.getStore();
                            return r && r.abortController.abort(Object.defineProperty(Error("Accessed fallback `params` during prerendering."), "__NEXT_ERROR_CODE", {
                                value: "E691",
                                enumerable: !1,
                                configurable: !0
                            })), new Proxy(n.apply(e, t), v)
                        }
                    })[t]
                }
                return i.ReflectAdapter.get(e, t, r)
            }
        };

    function O(e) {
        let t = S.get(e);
        if (t) return t;
        let r = Promise.resolve(e);
        return S.set(e, r), r
    }(0, f.createDedupedByCallsiteServerErrorLoggerDev)(function(e, t) {
        let r = e ? `Route "${e}" ` : "This route ";
        return Object.defineProperty(Error(`${r}used ${t}. \`params\` is a Promise and must be unwrapped with \`await\` or \`React.use()\` before accessing its properties. Learn more: https://nextjs.org/docs/messages/sync-dynamic-apis`), "__NEXT_ERROR_CODE", {
            value: "E834",
            enumerable: !1,
            configurable: !0
        })
    })
}, 66863, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "ClientPageRoot", {
        enumerable: !0,
        get: function() {
            return u
        }
    });
    let n = e.r(87433),
        a = e.r(28933),
        o = e.r(31270),
        i = e.r(44440),
        s = e.r(26883),
        c = e.r(65663);

    function u({
        Component: t,
        serverProvidedParams: r
    }) {
        let u, l;
        if (null !== r) u = r.searchParams, l = r.params;
        else {
            let e = (0, i.use)(o.LayoutRouterContext);
            l = null !== e ? e.parentParams : {}, u = (0, s.urlSearchParamsToParsedUrlQuery)((0, i.use)(c.SearchParamsContext))
        }
        if ("u" < typeof window) {
            let r, o, {
                    workAsyncStorage: i
                } = e.r(42907),
                s = i.getStore();
            if (!s) throw Object.defineProperty(new a.InvariantError("Expected workStore to exist when handling searchParams in a client Page."), "__NEXT_ERROR_CODE", {
                value: "E564",
                enumerable: !1,
                configurable: !0
            });
            let {
                createSearchParamsFromClient: c
            } = e.r(52772);
            r = c(u, s);
            let {
                createParamsFromClient: d
            } = e.r(87468);
            return o = d(l, s), (0, n.jsx)(t, {
                params: o,
                searchParams: r
            })
        } {
            let {
                createRenderSearchParamsFromClient: r
            } = e.r(6763), a = r(u), {
                createRenderParamsFromClient: o
            } = e.r(15735), i = o(l);
            return (0, n.jsx)(t, {
                params: i,
                searchParams: a
            })
        }
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 99113, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "ClientSegmentRoot", {
        enumerable: !0,
        get: function() {
            return s
        }
    });
    let n = e.r(87433),
        a = e.r(28933),
        o = e.r(31270),
        i = e.r(44440);

    function s({
        Component: t,
        slots: r,
        serverProvidedParams: s
    }) {
        let c;
        if (null !== s) c = s.params;
        else {
            let e = (0, i.use)(o.LayoutRouterContext);
            c = null !== e ? e.parentParams : {}
        }
        if ("u" < typeof window) {
            let o, {
                    workAsyncStorage: i
                } = e.r(42907),
                s = i.getStore();
            if (!s) throw Object.defineProperty(new a.InvariantError("Expected workStore to exist when handling params in a client segment such as a Layout or Template."), "__NEXT_ERROR_CODE", {
                value: "E600",
                enumerable: !1,
                configurable: !0
            });
            let {
                createParamsFromClient: u
            } = e.r(87468);
            return o = u(c, s), (0, n.jsx)(t, { ...r,
                params: o
            })
        } {
            let {
                createRenderParamsFromClient: a
            } = e.r(15735), o = a(c);
            return (0, n.jsx)(t, { ...r,
                params: o
            })
        }
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 74534, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "IconMark", {
        enumerable: !0,
        get: function() {
            return a
        }
    });
    let n = e.r(87433),
        a = () => "u" > typeof window ? null : (0, n.jsx)("meta", {
            name: "«nxt-icon»"
        })
}]);