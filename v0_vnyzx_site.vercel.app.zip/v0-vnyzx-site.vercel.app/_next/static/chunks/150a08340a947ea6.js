(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 62924, (e, t, r) => {
    t.exports = e.r(37109)
}, 99956, e => {
    "use strict";
    var t = e.i(17141),
        r = e.i(44440),
        n = e.i(62924);

    function a() {
        return "u" > typeof window
    }

    function o() {
        return "production"
    }

    function i() {
        return "development" === ((a() ? window.vam : o()) || "production")
    }

    function s(e) {
        return RegExp(`/${e.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}(?=[/?#]|$)`)
    }

    function u(e) {
        return (0, r.useEffect)(() => {
            var t;
            e.beforeSend && (null == (t = window.va) || t.call(window, "beforeSend", e.beforeSend))
        }, [e.beforeSend]), (0, r.useEffect)(() => {
            ! function(e = {
                debug: !0
            }) {
                var t;
                if (!a()) return;
                ! function(e = "auto") {
                    if ("auto" === e) {
                        window.vam = o();
                        return
                    }
                    window.vam = e
                }(e.mode), window.va || (window.va = function(...e) {
                    (window.vaq = window.vaq || []).push(e)
                }), e.beforeSend && (null == (t = window.va) || t.call(window, "beforeSend", e.beforeSend));
                let r = e.scriptSrc ? e.scriptSrc : i() ? "https://va.vercel-scripts.com/v1/script.debug.js" : e.basePath ? `${e.basePath}/insights/script.js` : "/_vercel/insights/script.js";
                if (document.head.querySelector(`script[src*="${r}"]`)) return;
                let n = document.createElement("script");
                n.src = r, n.defer = !0, n.dataset.sdkn = "@vercel/analytics" + (e.framework ? `/${e.framework}` : ""), n.dataset.sdkv = "1.6.1", e.disableAutoTrack && (n.dataset.disableAutoTrack = "1"), e.endpoint ? n.dataset.endpoint = e.endpoint : e.basePath && (n.dataset.endpoint = `${e.basePath}/insights`), e.dsn && (n.dataset.dsn = e.dsn), n.onerror = () => {
                    let e = i() ? "Please check if any ad blockers are enabled and try again." : "Be sure to enable Web Analytics for your project and deploy again. See https://vercel.com/docs/analytics/quickstart for more information.";
                    console.log(`[Vercel Web Analytics] Failed to load script from ${r}. ${e}`)
                }, i() && !1 === e.debug && (n.dataset.debug = "false"), document.head.appendChild(n)
            }({
                framework: e.framework || "react",
                basePath: e.basePath ? ? function() {
                    if (void 0 !== t.default && void 0 !== t.default.env) return t.default.env.REACT_APP_VERCEL_OBSERVABILITY_BASEPATH
                }(),
                ...void 0 !== e.route && {
                    disableAutoTrack: !0
                },
                ...e
            })
        }, []), (0, r.useEffect)(() => {
            e.route && e.path && function({
                route: e,
                path: t
            }) {
                var r;
                null == (r = window.va) || r.call(window, "pageview", {
                    route: e,
                    path: t
                })
            }({
                route: e.route,
                path: e.path
            })
        }, [e.route, e.path]), null
    }

    function c(e) {
        let a, o, i, {
            route: c,
            path: d
        } = (a = (0, n.useParams)(), o = (0, n.useSearchParams)(), i = (0, n.usePathname)(), a ? {
            route: function(e, t) {
                if (!e || !t) return e;
                let r = e;
                try {
                    let e = Object.entries(t);
                    for (let [t, n] of e)
                        if (!Array.isArray(n)) {
                            let e = s(n);
                            e.test(r) && (r = r.replace(e, `/[${t}]`))
                        }
                    for (let [t, n] of e)
                        if (Array.isArray(n)) {
                            let e = s(n.join("/"));
                            e.test(r) && (r = r.replace(e, `/[...${t}]`))
                        }
                    return r
                } catch (t) {
                    return e
                }
            }(i, Object.keys(a).length ? a : Object.fromEntries(o.entries())),
            path: i
        } : {
            route: null,
            path: i
        });
        return r.default.createElement(u, {
            path: d,
            route: c,
            ...e,
            basePath: function() {
                if (void 0 !== t.default && void 0 !== t.default.env) return t.default.env.NEXT_PUBLIC_VERCEL_OBSERVABILITY_BASEPATH
            }(),
            framework: "next"
        })
    }

    function d(e) {
        return r.default.createElement(r.Suspense, {
            fallback: null
        }, r.default.createElement(c, { ...e
        }))
    }
    e.s(["Analytics", () => d])
}]);